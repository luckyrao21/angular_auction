import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sec-nav',
  templateUrl: './sec-nav.component.html',
  styleUrls: ['./sec-nav.component.css']
})
export class SecNavComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
