import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home-main-content',
  templateUrl: './home-main-content.component.html',
  styleUrls: ['./home-main-content.component.css']
})
export class HomeMainContentComponent implements OnInit {
  constructor() { }

  ngOnInit(): void {
  }

}

