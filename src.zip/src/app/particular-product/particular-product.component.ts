import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-particular-product',
  templateUrl: './particular-product.component.html',
  styleUrls: ['./particular-product.component.css']
})
export class ParticularProductComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
